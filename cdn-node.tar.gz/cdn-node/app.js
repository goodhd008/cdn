const express = require('express')
const morgan = require("morgan");
const createError = require('http-errors');
const mongoose = require('mongoose');
const _ = require('lodash');
const multer = require('multer');
const { body, query, param, validationResult, check, oneOf } = require('express-validator');
const config = require('./config/config');
const request = require('request');
const fs = require('fs');
const sharp = require('sharp');
const { nanoid } = require('nanoid');
const File = require('./models/file');
const urlParse = require('url-parse');
const path = require('path');
const si = require('systeminformation');
const agenda = require('./helper/agenda');
const checkDiskSpace = require('check-disk-space').default;
const URL = require("url").URL;

const redis = require('redis');
const client = redis.createClient();
client.on('error', (err) => console.log('Redis Client Error', err));

(async () => {
  await client.connect();
  await agenda.startJob();
})();

// const storage = multer.memoryStorage();
// const upload = multer({
//   storage: storage,
//   fileFilter: function (req, file, cb) {
//     if (file.mimetype !== 'image/png' && file.mimetype !== 'image/jpg' && file.mimetype !== 'image/jpeg') {
//       cb(null, false);
//     }
//     else {
//       cb(null, true);
//     }
//   }
// });

const app = express()
const port = normalizePort(process.env.PORT || "3300");

// mongodb
const options = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  autoIndex: true,
};
mongoose.connect(
  'mongodb://' +
  config.dbUser +
  ':' +
  config.dbPassword +
  '@' + config.dbUrl + '/' +
  config.db,
  options
);

app.set('trust proxy', 1);
app.use(morgan('dev'));
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ limit: '5mb', extended: false, parameterLimit: 10000 }));
app.use('/public', express.static('public'));


app.get('/', (req, res) => {
  const accept = req.headers.accept;
  let supportWebp = false;
  if (accept && accept.indexOf('image/webp')) {
    supportWebp = true;
  }
  res.send('Hello World!')
})
app.get('/api/sysinfo', checkApiKey, async (req, res) => {
  const result = await Promise.all([si.cpu(), si.mem(), si.osInfo(), si.fsSize(), si.currentLoad(), si.networkStats()]);
  res.json(result);
});
app.get('/api/stat', checkApiKey, async (req, res) => {
  const result = await Promise.all([si.mem(), si.currentLoad(), si.networkStats()])
  res.json(result);
});
app.get('/api/network', checkApiKey, async (req, res) => {
  const result = await si.networkStats();
  res.json(result);
});
app.get('/api/diskspace', checkApiKey, async (req, res) => {
  checkDiskSpace(__dirname).then((diskSpace) => {
    return res.json(diskSpace);
    // {
    //     diskPath: 'C:',
    //     free: 12345678,
    //     size: 98756432
    // }
    // Note: `free` and `size` are in bytes
  })
})
app.post('/api/purge',
  checkApiKey,
  body('urls').notEmpty(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const rootPath = path.join(__dirname, 'public');
    let { urls } = req.body;
    const r = /\r\n|[\r\n]/;
    const urlsArr = urls.split(r);
    const files = await File.find({ url: { $in: urlsArr } });
    for (let index = 0; index < files.length; index++) {
      const file = files[index];
      await File.deleteOne({ _id: file._id });
      fs.unlinkSync(rootPath + '/tmp/' + file.nid);
    }
    res.json({ success: 1 });
  });
app.get(/^\/(videos|public|stream)\/.*(ts|png)$/,
  checkReferers,
  async (req, res) => {
    const rootPath = path.join(__dirname, 'public');
    const url = req.url;
    const file = await File.findOne({ key: 'efvcms', url: url });
    res.set('Cache-Control', 'public, max-age=31536000');
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    if (file) {
      File.updateOne({ _id: file._id }, { lastSeen: Date.now() }, function (err, res) {
        if (err) {
          console.log(err);
        }
      });
      res.header('Content-Type', 'application/octet-stream');
      res.header('Content-Disposition', 'inline; filename=efvserver');
      return res.sendFile(rootPath + '/tmp/' + file.nid);
    }
    request
      .get(config.efvDomain + url)
      .on('error', function (err) {
        res.json({ success: 0, message: err.message });
      })
      .on('response', async function (response) {
        // 'image/png' or 'video/mp2t'
        const type = response.headers['content-type'];
        if (type != 'image/png' && type != 'video/mp2t') {
          return res.json({ success: 0, message: 'wrong ts from efvcms' });
        }
        let buffer = Buffer.from('', 'binary');
        response.on('data', function(data) {
          buffer = Buffer.concat([buffer, data]);
        });
        response.on('end', async function() {
          const nid = nanoid();
          const desPath = './public/tmp/' + nid;
          const freeDisk = await client.get('disk free');
          console.log(freeDisk);//0.1代表还剩10%，大于20%剩余才储存数据
          if (freeDisk && freeDisk * 1 > 0.2) {
            File.create({ nid, key: 'efvcms', url: url }, function (err) {
              if (err) {
                console.log(err);
              }
            });
            fs.writeFile(desPath, buffer,  "binary", function(err) {
              if(err) console.log(err);
            });
          }
          res.send(Buffer.from(buffer, 'binary'));
        });
        // const nid = nanoid();
        // const desPath = './public/tmp/' + nid;
        // response.pipe(res);
        // const freeDisk = await client.get('disk free');
        // console.log(freeDisk);//0.1代表还剩10%，大于20%剩余才储存数据
        // if (freeDisk && freeDisk * 1 > 0.2) {
        //   File.create({ nid, key: 'efvcms', url: url }, function (err) {
        //     if (err) {
        //       console.log(err);
        //     }
        //   });
        //   const writeStream = fs.createWriteStream(desPath);
        //   response.pipe(writeStream);
        //   writeStream.on('finish', async function () {
        //   });
        // }
      });
  }
)
app.get(/^\/(images)\/.*(jpg|JPG|png|PNG|jpeg|JPEG|gif|GIF|webp|WEBP)$/, 
oneOf([
  check('width').notEmpty().isInt({ min: 20, max: 3000 }).toInt(),
  check('height').notEmpty().isInt({ min: 30, max: 6000 }).toInt(),
]),
query('format').default('webp').trim().isIn(['webp', 'jpg', 'png']),
query('force').default(false).isBoolean(),
checkReferers, async (req, res) => {
  const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const url = req.url;
    const rootPath = path.join(__dirname, 'public');
    let { width, height, format, force } = req.query;
    const realUrl = config.efvDomain + url;
    try {
      new URL(realUrl)
    } catch (error) {
      console.log(error);
      return res.json({success: 0, message: '不是正确链接！'})
    }
    const urlObject = new urlParse(realUrl);
    // console.log(urlObject);
    let limit = false;
    const whiteLists = config.whiteLists;
    if (whiteLists && whiteLists.length > 0) {
      limit = true;
    }
    if (limit) {
      if (whiteLists.indexOf(urlObject.host) == -1) {
        return res.json({ success: 0, message: 'only allow given host！' });
      }
    }
    const resizeObj = {};
    if (height && height > 6000) {
      height = 6000;
    }
    if (width && width > 3000) {
      width = 3000;
    }
    if (height) {
      resizeObj.height = height;
    }
    if (width) {
      resizeObj.width = width;
    }
    const accept = req.headers.accept;
    let supportWebp = false;
    if (accept && accept.indexOf('image/webp') > -1) {
      supportWebp = true;
    }
    if (format == 'webp' && !supportWebp && !force) {
      format = 'jpg';
    }
    const imageUrl = urlObject.protocol + '//' + urlObject.host + urlObject.pathname;
    let key = 'f-' + format;
    if (width) {
      key += 'w-' + width;
    }
    if (height) {
      key += 'h-' + height;
    }
    const file = await File.findOne({ key, url: imageUrl });
    res.set('Cache-Control', 'public, max-age=31536000');
    if (file) {
      File.updateOne({ _id: file._id }, { $inc: { views: 1 }, lastSeen: Date.now() }, function (err, res) {
        if (err) {
          console.log(err);
        }
      });
      res.header('Content-Type', 'image/' + format);
      res.header('Content-Disposition', 'inline; filename=index.' + format);
      return res.sendFile(rootPath + '/tmp/' + file.nid);
    }
    request
      .get(config.efvDomain + url)
      .on('error', function (err) {
        res.json({ success: 0, message: err.message });
      })
      .on('response', async function (response) {
        const type = response.headers['content-type'];
        if (type != 'image/png' && type != 'image/jpg' && type != 'image/jpeg' && type != 'image/webp' && type != 'image/gif') {
          return res.json({ success: 0, message: 'wrong image！' });
        }
        const nid = nanoid();
        const desPath = './public/tmp/' + nid;
        const writeStream = fs.createWriteStream(desPath);
        response.pipe(writeStream);
        writeStream.on('finish', async function () {
          const nid = nanoid();
          const newDesPath = './public/tmp/' + nid;
          let info;
          try {
            if(type == 'image/gif') {
              info = await sharp(desPath, {animated: true})
                .resize(resizeObj)
                .toFormat(format)
                .toFile(newDesPath);
            } else {
              info = await sharp(desPath)
                .resize(resizeObj)
                .toFormat(format)
                .toFile(newDesPath);
            }
          } catch (error) {
            console.log(error + url);
            format = 'jpg';
            info = await sharp(desPath)
              .resize(resizeObj)
              .toFormat('jpg')
              .toFile(newDesPath).catch((err) => {
                fs.copyFileSync(desPath, newDesPath);
              })
          }
          // const readStream = fs.createReadStream(newDesPath);
          // readStream.pipe(res);
          if(!info) {
            info = await sharp(newDesPath).metadata();
          }
          File.create({ nid, key, url: imageUrl, width: info.width, height: info.height, size: info.size }, function (err) {
            if (err) {
              console.log(err);
            }
          });
          res.header('Content-Type', 'image/' + format);
          res.header('Content-Disposition', 'inline; filename=index.' + format);
          res.sendFile(rootPath + '/tmp/' + nid);
          sharp.cache(false);
          fs.unlink(desPath, function (err) {
            if (err) {
              console.log(err);
            }
          });
      });
    });
});
app.get('/api',
  query('url').notEmpty().trim(),
  oneOf([
    check('width').notEmpty().isInt({ min: 20, max: 3000 }).toInt(),
    check('height').notEmpty().isInt({ min: 30, max: 6000 }).toInt(),
  ]),
  query('format').default('webp').trim().isIn(['webp', 'jpg', 'png']),
  query('force').default(false).isBoolean(),
  checkReferers,
  banUrls,
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const rootPath = path.join(__dirname, 'public');
    let { url, width, height, format, force } = req.query;
    // console.log(url);
    try {
      new URL(url)
    } catch (error) {
      console.log(error);
      return res.json({success: 0, message: '不是正确链接！'})
    }
    const urlObject = new urlParse(url);
    // console.log(urlObject);
    let limit = false;
    const whiteLists = config.whiteLists;
    if (whiteLists && whiteLists.length > 0) {
      limit = true;
    }
    if (limit) {
      if (whiteLists.indexOf(urlObject.host) == -1) {
        return res.json({ success: 0, message: 'only allow given host！' });
      }
    }
    const resizeObj = {};
    if (height && height > 6000) {
      height = 6000;
    }
    if (width && width > 3000) {
      width = 3000;
    }
    if (height) {
      resizeObj.height = height;
    }
    if (width) {
      resizeObj.width = width;
    }
    const accept = req.headers.accept;
    let supportWebp = false;
    if (accept && accept.indexOf('image/webp') > -1) {
      supportWebp = true;
    }
    if (format == 'webp' && !supportWebp && !force) {
      format = 'jpg';
    }
    const imageUrl = urlObject.protocol + '//' + urlObject.host + urlObject.pathname;
    let key = 'f-' + format;
    if (width) {
      key += 'w-' + width;
    }
    if (height) {
      key += 'h-' + height;
    }
    const file = await File.findOne({ key, url: imageUrl });
    res.set('Cache-Control', 'public, max-age=31536000');
    if (file) {
      File.updateOne({ _id: file._id }, { $inc: { views: 1 }, lastSeen: Date.now() }, function (err, res) {
        if (err) {
          console.log(err);
        }
      });
      res.header('Content-Type', 'image/' + format);
      res.header('Content-Disposition', 'inline; filename=index.' + format);
      return res.sendFile(rootPath + '/tmp/' + file.nid);
    }
    // console.log(url);
    // console.log(encodeURI(url));
    request
      .get(encodeURI(url))
      .on('error', function (err) {
        res.json({ success: 0, message: err.message });
      })
      .on('response', function (response) {
        // 'image/png'
        // console.log(response);
        const type = response.headers['content-type'];
        if (type != 'image/png' && type != 'image/jpg' && type != 'image/jpeg' && type != 'image/webp' && type != 'image/gif') {
          return res.json({ success: 0, message: 'wrong image！' });
        }
        const nid = nanoid();
        const desPath = './public/tmp/' + nid;
        const writeStream = fs.createWriteStream(desPath);
        response.pipe(writeStream);
        writeStream.on('finish', async function () {
          const nid = nanoid();
          const newDesPath = './public/tmp/' + nid;
          let info;
          try {
            if(type == 'image/gif') {
              info = await sharp(desPath, {animated: true})
                .resize(resizeObj)
                .toFormat(format)
                .toFile(newDesPath);
            } else {
              info = await sharp(desPath)
                .resize(resizeObj)
                .toFormat(format)
                .toFile(newDesPath);
            }
          } catch (error) {
            console.log(error + url);
            format = 'jpg';
            info = await sharp(desPath)
              .resize(resizeObj)
              .toFormat('jpg')
              .toFile(newDesPath).catch((err) => {
                fs.copyFileSync(desPath, newDesPath);
              });
          }
          if(!info) {
            info = await sharp(newDesPath).metadata();
          }
          // const readStream = fs.createReadStream(newDesPath);
          // readStream.pipe(res);
          File.create({ nid, key, url: imageUrl, width: info.width, height: info.height, size: info.size }, function (err) {
            if (err) {
              console.log(err);
            }
          });
          res.header('Content-Type', 'image/' + format);
          res.header('Content-Disposition', 'inline; filename=index.' + format);
          res.sendFile(rootPath + '/tmp/' + nid);
          sharp.cache(false);
          fs.unlink(desPath, function (err) {
            if (err) {
              console.log(err);
            }
          });
        });
      })
  });

app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.json({ success: 0 });
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})

function normalizePort(val) {
  var port = parseInt(val, 10)

  if (isNaN(port)) {
    // named pipe
    return val
  }

  if (port >= 0) {
    // port number
    return port
  }

  return false
}
function checkApiKey(req, res, next) {
  const apikey = req.body.apikey || req.query.apikey || req.headers.apikey;
  if (apikey != config.apiKey) {
    console.log('not right');
    return res.json({ success: 0, message: 'apiKey验证错误，请核实！' });
  }
  req.apikey = apikey;
  next();
}
function banUrls(req, res, next) {
  const banLists = config.banurls;
  let block = false;
  for (let index = 0; index < banLists.length; index++) {
    const url = banLists[index];
    const requestUrl = req.query.url;
    if(requestUrl.indexOf(url) > -1) {
      block = true;
    }
  }
  if(block) {
    return res.redirect('https://wmdb.querydata.org/movie/403.png');
  } else {
    next();
  }
}
function checkReferers(req, res, next) {
  // console.log(req.headers.referer);
  // console.log(whiteLists);
  // console.log(blackLists);
  // console.log(req.baseUrl);
  const apikey = req.query.apikey;
  if (apikey == config.apiKey) {
    return next();
  }
  const whiteLists = config.antiurls;
  const referer = req.headers.referer;
  let block = true;
  for (let index = 0; index < whiteLists.length; index++) {
    const domain = whiteLists[index];
    if (referer && referer.indexOf(domain) > -1) {
      block = false;
    }
  }
  if(whiteLists.length == 0) {
    block = false;
  }
  if(block) {
    return res.redirect('https://wmdb.querydata.org/movie/403.png');
  } else {
    next();
  }
}