module.exports = {
  dbUrl: "127.0.0.1",
  db: "efvcdn",
  dbUser: "efvcdn",
  dbPassword: "efvcdn",
  apiKey: 'iqi36022bytheway',
  efvDomain: 'https://127.0.0.1:4000',
  whiteLists: [
  ],
  antiurls: [
  ],
  banurls: [],
  keeptime: 2 //单位分钟 Minutes
};